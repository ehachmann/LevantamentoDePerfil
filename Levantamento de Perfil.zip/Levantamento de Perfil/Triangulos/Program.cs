﻿using System;
using System.Diagnostics.Eventing.Reader;

namespace Triangulos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string menu = "1";
            while (menu != "2")
            {
                Console.WriteLine("Jogo de Triângulos");
                Console.WriteLine("Escolha uma das Opções:");
                Console.WriteLine();

                Console.WriteLine("1 - Verificar um novo Triângulo");
                Console.WriteLine("2 - Sair");
                Console.WriteLine();
                menu = (Console.ReadLine());

                switch (menu)
                {
                    case "1":
                        Console.WriteLine("Informe o valor X do triângulo: ");
                        double x = double.Parse(Console.ReadLine());

                        Console.WriteLine("Informe o valor Y do triângulo: ");
                        double y = double.Parse(Console.ReadLine());

                        Console.WriteLine("Informe o valor Z do triângulo: ");
                        double z = double.Parse(Console.ReadLine());

                        if (x + y > z && x + z > y && y + z > x)
                        {
                            if ((x == y && x == z) || (y == x && y == z) || (z == x && z == y))
                            {
                                Console.Clear();
                                Console.WriteLine("O resultado é um Triângulo Equilátero");
                                Console.WriteLine();
                            }
                            else if (x == y || x == z || y == z)
                            {
                                Console.Clear();
                                Console.WriteLine("O resultado é um Triângulo Isósceles");
                                Console.WriteLine();
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("O resultado é um Triângulo Escaleno");
                                Console.WriteLine();
                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Triângulo Inválido");
                            Console.WriteLine();
                        }
                        break;

                    case "2":
                        Console.WriteLine("Saindo...");
                        break;

                    default:
                        Console.Clear();
                        Console.WriteLine("Opção inválida");
                        Console.WriteLine();
                        break;
                }
            }
        }
    }
}

