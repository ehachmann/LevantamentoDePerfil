﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace CorridaDeDados
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] pista = new int[31];
            int jogador = 0;
            int posicaoJogador = 0;
            int posicaoComputador = 0;
            int computador = 0;
            int final = 0;
            int rodadaExtra = 6;

            Random dado = new Random();

            Console.WriteLine("Jogo de Corrida de Dados");
            Console.WriteLine();
            Console.WriteLine("**** Regras do Jogo ****");
            Console.WriteLine();
            Console.WriteLine("1º - O jogador lança o dado com a tecla 'Enter'");
            Console.WriteLine("2º - O computador lança o dado automaticamente");
            Console.WriteLine("3º - Avanço extra de 3 casas caso o competidor cair nas casas 10, 15 ou 20");
            Console.WriteLine("4º - Recuo de 2 casas, caso o competidor cair nas casas 7, 13 ou 18");
            Console.WriteLine("5º - Joga novamente caso tirar 6 no lançamento do dado");
            Console.WriteLine("6º - O competidor que chegar ou ultrapassar 30 pontos primeiro é o Vencedor!!!");
            Console.WriteLine();


            // Laço de repetição para validar o vencedor 

            while (final < 30)
            {
                Console.WriteLine("Jogador - Pressione 'Enter' para lançar o dado");
                string enter = Console.ReadLine();
                Console.Clear();

                // Lançamento dado do jogador

                jogador = dado.Next(1, 7);
                posicaoJogador = posicaoJogador + jogador;
                Console.WriteLine($"Jogador tirou: {jogador}");
                if (jogador == rodadaExtra)
                {
                    jogador = dado.Next(1, 7);
                    Console.WriteLine($"Jogador jogou novamente e tirou: {jogador}");
                    posicaoJogador = posicaoJogador + jogador;
                }
                else if (posicaoJogador == 10 || posicaoJogador == 16 || posicaoJogador == 22)
                {
                    Console.WriteLine("O Jogador avançou mais duas casas porque caiu na casa bônus");
                    posicaoJogador = posicaoJogador + 2;
                }
                else if (posicaoJogador == 13 || posicaoJogador == 17 || posicaoJogador == 23)
                {
                    Console.WriteLine("O Jogador recuou 2 casas porque caiu na casa de penalidade");
                    posicaoJogador = posicaoJogador - 2;
                }

                // Lançamento dado do computador

                computador = dado.Next(1, 7);
                posicaoComputador = posicaoComputador + computador;
                Console.WriteLine($"Computador tirou: {computador}");
                if (computador == rodadaExtra)
                {
                    computador = dado.Next(1, 7);
                    Console.WriteLine($"O Computador jogou novamente e tirou: {computador}");
                    posicaoComputador = posicaoComputador + computador;
                }
                else if (posicaoComputador == 10 || posicaoComputador == 16 || posicaoComputador == 22)
                {
                    Console.WriteLine("O Computador avançou mais duas casas porque caiu na casa bônus");
                    posicaoComputador = posicaoComputador + 2;
                }
                else if (posicaoComputador == 13 || posicaoComputador == 17 || posicaoComputador == 23)
                {
                    Console.WriteLine("O Computador recuou 2 casas porque caiu na casa de penalidade");
                    posicaoComputador = posicaoComputador - 2;
                }

                // Repetição para listar a posição dos jogadores

                for (int i = 1; i < 31; i++)
                {
                    pista[i] = i;

                    if (pista[i] == posicaoJogador)
                    {
                        if (posicaoJogador == posicaoComputador)
                        {
                            Console.WriteLine($"Pista {pista[i]} - Posição: Jogador e Computador");
                        }
                        else
                            Console.WriteLine($"Pista {pista[i]} - Posição: Jogador");
                    }
                    else if (pista[i] == posicaoComputador)
                    {
                        if (posicaoJogador == posicaoComputador)
                        {
                            Console.WriteLine($"Pista {pista[i]} - Posição: Jogador e Computador");
                        }
                        else
                            Console.WriteLine($"Pista {pista[i]} - Posição: Computador");
                    }
                    else
                    {
                        Console.WriteLine($"Pista {pista[i]}");
                    }
                }

                // Verificar Vencedor

                if (posicaoJogador >= 30 || posicaoComputador >= 30)
                {
                    final = 30;
                    if (posicaoJogador == posicaoComputador)
                    {
                        Console.WriteLine("O Jogador e o Computador empataram a partida");
                    }
                    else if (posicaoJogador > posicaoComputador)
                    {
                        Console.WriteLine($"O Jogador foi o grande Campeão!!!");
                    }
                    else
                    {
                        Console.WriteLine($"O Computador foi o grande Campeão!!!");
                    }
                }
            }
        }
    }
}



