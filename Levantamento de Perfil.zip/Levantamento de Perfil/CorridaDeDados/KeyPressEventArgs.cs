﻿namespace CorridaDeDados
{
    internal class KeyPressEventArgs
    {
        public object KeyChar { get; internal set; }
    }
}